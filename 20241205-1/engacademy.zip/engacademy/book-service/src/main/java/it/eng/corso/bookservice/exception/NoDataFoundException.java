package it.eng.corso.bookservice.exception;

public class NoDataFoundException extends RuntimeException{
}
