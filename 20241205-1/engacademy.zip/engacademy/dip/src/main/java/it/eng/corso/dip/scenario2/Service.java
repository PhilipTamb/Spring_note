package it.eng.corso.dip.scenario2;

public interface Service {
    void saluta();
}
