package it.eng.corso.dip.scenario1;

public class Main {

    public static void main(String[] args) {
        Client client = new Client();
        client.miaLogica();
    }
}
