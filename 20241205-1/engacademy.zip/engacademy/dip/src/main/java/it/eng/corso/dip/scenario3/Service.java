package it.eng.corso.dip.scenario3;

public interface Service {
    void saluta();
}
