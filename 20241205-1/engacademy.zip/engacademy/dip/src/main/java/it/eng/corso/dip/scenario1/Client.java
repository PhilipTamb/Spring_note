package it.eng.corso.dip.scenario1;

public class Client {

    public void miaLogica(){
        Service service = new Service();
        service.saluta();
    }
}
