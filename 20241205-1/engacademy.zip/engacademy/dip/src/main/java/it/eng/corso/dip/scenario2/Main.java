package it.eng.corso.dip.scenario2;

public class Main {

    public static void main(String[] args) {
        ServiceLocator.getInstance().getClient().miaLogica();
    }
}
