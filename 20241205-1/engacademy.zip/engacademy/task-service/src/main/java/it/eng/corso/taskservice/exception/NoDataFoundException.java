package it.eng.corso.taskservice.exception;

public class NoDataFoundException extends RuntimeException{
}
