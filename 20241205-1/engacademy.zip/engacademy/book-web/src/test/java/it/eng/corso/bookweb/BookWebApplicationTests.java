package it.eng.corso.bookweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
