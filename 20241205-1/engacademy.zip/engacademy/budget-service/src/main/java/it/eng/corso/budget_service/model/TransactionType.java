package it.eng.corso.budget_service.model;

import lombok.Getter;


public enum TransactionType {
    INCOME,
    EXPENSE
}
